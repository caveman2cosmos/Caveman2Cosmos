## Sid Meier's Civilization 4
## Copyright Firaxis Games 2007
iPushButton = 0
iPushedButtonUnit = 0